#include <stdio.h>
#include <string.h>

int main()
{
    int i, k, length;
    char str[1000];
    
    printf("배열을 입력하세요\n");
    scanf("%s",str);
    k=strlen(str);
    
    for(i=k-1;i>=0;i--)
    {
        printf("%c",str[i]);
    }
}

