#include <stdio.h>
#include <string.h>

int main(void) {
    char input,output;
    
    printf("대소문자 변환 프로그램\n");
    input = getchar();
    while (1)
    {
        if (input == '\n')
            break;
        
        if (input<='Z' && input>='A')
        {
            output = input + 32;
            
        }
        else if (input<='z' && input>='a')
        {
            output = input - 32;
        }
        putchar(output);
        input = getchar();
    }
}


