#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void) {
    
    int com, com100, com10, com1;
    int input, input100, input10, input1;
    int max=0,min=1000000,i;
    double ave;
    int count=0;
    int count2=0;
    srand(time(NULL));
    
    while (1)
    {
        printf("3자리 수 입력\n");
        scanf("%d",&input);
        input100 = input / 100;
        input10 = (input-input100*100) / 10;
        input1 = input-input100*100-input10*10;
        
        if (input100 != input10)
            if( input100 != input1)
                if( input10 != input1 )
                    break;
    }
    printf("숫자야구를 시작합니다.\n");
    
    for(i=0;i<100;i++)
    {
        count = 0;
        while (1)
        {
            com = rand() % 1000;
            com100 = com / 100;
            com10 = (com-com100*100) / 10;
            com1 = com-com100*100-com10*10;
            
            if (com==input)
                break;
            
            if (com100 == com10 || com100 == com1 || com10 == com1 )
                continue;
            
            count++;
            
        }
        count2 += count;
        
        if (count < min)
            min = count;
        if (count > max)
            max = count;
    }
    ave = count2 / 100;
    printf("최대 : %d, 최소 : %d, 평균 : %lf\n",max,min,ave);
}

