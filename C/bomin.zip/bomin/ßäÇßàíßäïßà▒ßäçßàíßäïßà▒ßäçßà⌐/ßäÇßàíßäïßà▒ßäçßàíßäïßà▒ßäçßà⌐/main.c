#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void){
    
    int input, a;
    int draw = 0, win = 0, lose = 0;
    
    
    srand((int)time(NULL));
    
    while (1){
        
        printf("바위는 1, 가위는 2, 보는 3, 종료는 4: ");
        scanf("%d", &input);
        
        if (input == 4)
            break;
        
        a = rand() % 3 + 1;
        
        
        if (input == a)
        {
            draw++;
        }
        if (input-a==1 || input-a==-2)
        {
            win++;
        }
        if (input-a==-1 || input-a== 2)
        {
            lose++;
        }
        
        
    }
    
    printf("게임의 결과 : %d승, %d무, %d패", win, draw, lose);
    
    return 0;
}
